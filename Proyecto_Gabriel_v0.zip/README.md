## Orkdate

Este es mi proyecto final para el ciclo de Formación Profesional de Desarrollo de Aplicaciones Web.

### ¿En qué consiste OrkDate?

OrkDate es una aplicación web que permite al usuario encontrar a otras personas con las que 
jugar a partidas de rol. Después de registrarse en la aplicación, el usuario deberá crear un 
personaje para poder ver los perfiles de otros usuarios. Todos los personajes creados serán orcos.

Si dos usuarios están interesados el uno en el otro, harán “match” y podrán participar juntos 
en una aventura guionizada. A lo largo de esta aventura se encontrarán con diferentes dilemas y 
obstáculos. Los participantes deberán hablar entre sí a través de un chat para decidir la mejor 
solución y así poder avanzar.

### ¿Por qué orcos?

Entre las críticas que se suelen verter contra las aplicaciones de citas, una de las más comunes 
es la importancia que le dan a los aspectos más superficiales de los usuarios registrados. Esto 
se debe a que el funcionamiento de la mayoría de estas apps gira principalmente en torno a 
valorar a otras personas por su aspecto físico.

La decisión de que todos los personajes creados en OrkDate sean orcos está dirigida a satirizar 
ese funcionamiento y también a distanciarse de él. En una aplicación en donde todos los usuarios 
son orcos (comunmente considerados como criaturas superficialmente feas), será fundamental valorar 
aspectos menos superficiales de los perfiles que te encuentres.
