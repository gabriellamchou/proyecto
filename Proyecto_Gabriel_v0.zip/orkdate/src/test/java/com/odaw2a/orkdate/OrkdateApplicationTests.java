package com.odaw2a.orkdate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrkdateApplicationTests {

	@Test
	void contextLoads() {
	}

}
