package com.odaw2a.orkdate.dtos;

import lombok.Data;

@Data
public class UsernameDto {
    private String username;
}
