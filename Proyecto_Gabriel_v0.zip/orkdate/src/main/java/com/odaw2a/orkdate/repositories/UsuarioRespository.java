package com.odaw2a.orkdate.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.odaw2a.orkdate.domain.Usuario;

public interface UsuarioRespository extends JpaRepository<Usuario, Long> {
    
    Usuario findByUsername(String username);

    // @Query("select u from Usuario u where u.id not like ?1")
    // List<Usuario> findAllButCurrent(Long id);

}
