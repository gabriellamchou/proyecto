package com.odaw2a.orkdate.domain;

public enum Rol {
    ADMIN, USUARIO, MANAGER
}
