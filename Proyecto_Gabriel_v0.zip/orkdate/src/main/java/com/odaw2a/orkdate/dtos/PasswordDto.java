package com.odaw2a.orkdate.dtos;

import lombok.Data;

@Data
public class PasswordDto {
    private String password;
}
